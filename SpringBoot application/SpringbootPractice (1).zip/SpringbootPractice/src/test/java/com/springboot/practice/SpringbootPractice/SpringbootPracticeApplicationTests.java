package com.springboot.practice.SpringbootPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
